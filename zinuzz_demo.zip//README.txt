INSTRUCTIONS


1. Package content

README.txt:
This instruction file.

.p-file:
ZiNuZZ(TM) resonant LLC converter software tool.



2. Installation

Extract the ZIP file into a free to be chosen directory/folder. Add the new directory/folder to the MATLAB(TM) path or execute the software tool directly from the chosen directory/folder.



3. Usage

Run the file by executing zinuzz_demo.

Optionally the font type and size of the GUI can be changed by including input parameters like zinuzz_demo('fonttype',fontsize). The default font type is 'Arial' with size 11. 



4. Additional remarks

The demo version of the tool is fixed for a given specification. The gray input fields are unlocked in the full version.



5. IP protection
Unrightfull usage of the ZiNuZZ(TM) software tool or copying (parts of) the ZiNuZZ(TM) software tool is strictly prohibited without prior written consent of ZeoN PowerTec.



Disclaimer
ZeoN PowerTec does not accept liability for any software tool errors or inaccuracies and consequential loss. 

(c) ZeoN PowerTec